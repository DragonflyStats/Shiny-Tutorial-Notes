headerPanel_2(
	HTML(
		'<div id="stats_header">
		Sea Ice Concentrations and Wind Events
		<a href="http://accap.uaf.edu" target="_blank">
		<img id="stats_logo" align="right" alt="ACCAP Logo" src="./img/accap_sidebyside.png" />
		</a>
		<a href="http://snap.uaf.edu" target="_blank">
		<img id="stats_logo" align="right" alt="SNAP Logo" src="./img/snap_sidebyside.png" />
		</a>
		</div>'
	), h3, "Wind events and sea ice"
)
